<?php
	$db_host = "localhost";
	$db_name = "scoreboard";
	$db_user = "root";
	$db_pass = "";	
		
	$db_con = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

	$mysqli = new mysqli($db_host,$db_user,$db_pass,$db_name);
?>