<?php

/*
 * Database Constants
 */
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'scoreboard');

//Connecting to the database
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

//checking the successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//making an array to store the response
$response = array();

//if there is a post request move ahead
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //getting the data from request
    $game_name = $_POST['game_name'];
    $home_team = $_POST['home_team'];
    $away_team = $_POST['away_team'];
    $away_team_score = $_POST['away_team_score'];
    $home_team_score = $_POST['home_team_score'];
    $period = $_POST['period'];
    $home_team_foul = $_POST['home_team_foul'];
    $away_team_foul = $_POST['away_team_foul'];
    $game_type = $_POST['game_type'];
	$serve = $_POST['serve'];

    if ($game_type == "basketball_scores") {

        $sql = "select * from basketball_scores where game_name = '" . $game_name . "' and period = '" . $period . "'";
        $query = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($query);

        if ($count > 0) {

            mysqli_query($conn, "update basketball_scores set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
                ,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "'
                ,period = '" . $period . "' ,home_team_foul = '" . $home_team_foul . "', away_team_foul = '" . $away_team_foul . "'
                where game_name = '" . $game_name . "' and period = '" . $period . "'"
            );
            $response['message'] = "Data successfully saved.";

        } else {

            mysqli_query($conn, "INSERT INTO basketball_scores (game_name, home_team ,away_team, away_team_score, home_team_score, period, home_team_foul, away_team_foul)
        VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period, $home_team_foul, $away_team_foul)");

            $response['message'] = "Data successfully saved.";
        }
    } else if ($game_type == "common_scores") {

        $sql = "select * from " . $game_type . " where game_name = '" . $game_name . "' and period = '" . $period . "'";
        $query = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($query);

        if ($count > 0) {

            mysqli_query($conn, "update " . $game_type . " set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
                ,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "'
                ,period = '" . $period . "' where game_name = '" . $game_name . "' and period = '" . $period . "'"
            );
            $response['message'] = "Data successfully saved.";

        } else {

            mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, home_team ,away_team, away_team_score, home_team_score, period)
        VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period)");

            $response['message'] = "Data successfully saved.";
        }

    } else {
		
		  $sql = "select * from " . $game_type . " where game_name = '" . $game_name . "' and period = '" . $period . "'";
        $query = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($query);

        if ($count > 0) {

            mysqli_query($conn, "update " . $game_type . " set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
                ,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "' ,serve = '" . $serve . "',period = '" . $period . "' where game_name = '" . $game_name . "' and period = '" . $period . "'"
            );
            $response['message'] = "Data successfully saved.";

        } else {

            mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, home_team ,away_team, away_team_score, home_team_score, period,serve)
        VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period, $serve)");

            $response['message'] = "Data successfully saved.";
        }
		
		
	}

} else {
    $response['error'] = true;
    $response['message'] = "Invalid request";
}

//displaying the data in json format
echo json_encode($response);



SELECT 
ME_POST.ID POST_ID 
, 0 as IS_DELETED_SHARED
,ME.ID USER_ID
,ME.USERNAME
,ME.FULL_NAME
,ME.IMAGE USER_IMAGE
,ME_POST.IMAGE
, ME_POST.CONTENT
, ME.ID GROUP_ID
, 'REGULAR_POST' POST_TYPE
, NULL ORGINAL_USERNAME
, NULL ORG_NAME
, NULL ORG_USER_IMAGE
, NULL ORG_MODIFIED
, NULL ORG_USER_ID
, ME_POST.IS_DELETED
,ME_POST.MODIFIED 
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN ME.ID = (SELECT b.user_id FROM likes as b where user_id =  ME.ID and post_id = ME_POST.ID and is_deleted = 0 ) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM users ME
LEFT JOIN posts ME_POST ON ME_POST.USER_ID= ME.ID
WHERE 
ME_POST.repost_id IS NULL
AND ME_POST.is_deleted != 1

union all


SELECT 
ME_POST.ID  
, 0 as IS_DELETED_SHARED
,THEM.ID USER_ID
,THEM.USERNAME
,THEM.FULL_NAME
,THEM.IMAGE USER_IMAGE
,ME_POST.IMAGE
, ME_POST.CONTENT
, FOL.FOLLOWER_USER_ID GROUP_ID
, 'REGULAR_POST' post_type
, NULL ORG_USERNAME
, NULL ORG_NAME
, NULL ORG_USER_IMAGE
, NULL ORG_MODIFIED
, NULL ORG_USER_ID
, ME_POST.IS_DELETED
,ME_POST.modified 
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN FOL.FOLLOWER_USER_ID = (SELECT b.user_id FROM likes as b where user_id =  FOL.FOLLOWER_USER_ID and post_id = ME_POST.ID and is_deleted = 0) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM follows FOL
LEFT JOIN users THEM ON THEM.id = FOL.USER_ID
LEFT JOIN posts ME_POST ON ME_POST.USER_ID= THEM.ID
WHERE 
ME_POST.REPOST_ID IS NULL
AND ME_POST.is_deleted != 1
AND FOL.is_deleted != 1

union all

 
SELECT 
ME_POST.ID
, ME_POST.IS_DELETED as IS_DELETED_SHARED
,ME.ID USER_ID
,ME.USERNAME
,ME.FULL_NAME
,ME.IMAGE USER_IMAGE
, SHARED_POST.IMAGE
, SHARED_POST.CONTENT
, ME.ID GROUP_ID
, 'SHARED_POST' post_type
, ORG_USER.USERNAME ORG_USERNAME
, ORG_USER.FULL_NAME ORG_NAME
, ORG_USER.IMAGE ORG_USER_IMAGE
, SHARED_POST.modified ORG_MODIFIED
, ORG_USER.ID ORG_USER_ID
, SHARED_POST.IS_DELETED
, ME_POST.modified
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN ME.ID = (SELECT b.user_id FROM likes as b where user_id = ME.ID and post_id = ME_POST.ID and is_deleted = 0) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM users ME
LEFT JOIN posts ME_POST ON ME_POST.USER_ID= ME.ID
INNER JOIN posts SHARED_POST ON ME_POST.REPOST_ID = SHARED_POST.ID
LEFT JOIN users ORG_USER ON ORG_USER.ID = SHARED_POST.USER_ID

union all


SELECT 
ME_POST.ID
, ME_POST.IS_DELETED as IS_DELETED_SHARED
,THEM.ID USER_ID
,THEM.USERNAME
,THEM.FULL_NAME
,THEM.IMAGE USER_IMAGE
, SHARED_POST.IMAGE
, SHARED_POST.CONTENT
, FOL.USER_ID GROUP_ID
, 'SHARED_POST' post_type
, ORG_USER.USERNAME ORG_USERNAME
, ORG_USER.FULL_NAME ORG_NAME
, ORG_USER.IMAGE ORG_USER_IMAGE
, SHARED_POST.modified ORG_MODIFIED
, ORG_USER.ID ORG_USER_ID
, SHARED_POST.IS_DELETED
, ME_POST.modified
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN FOL.USER_ID = (SELECT b.user_id FROM likes as b where user_id = FOL.USER_ID and post_id = ME_POST.ID and is_deleted = 0) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM follows FOL
LEFT JOIN users THEM ON THEM.ID = FOL.FOLLOWER_USER_ID
LEFT JOIN posts ME_POST ON ME_POST.USER_ID = FOL.FOLLOWER_USER_ID
INNER JOIN posts SHARED_POST ON ME_POST.REPOST_ID = SHARED_POST.ID
LEFT JOIN users ORG_USER ON ORG_USER.ID = SHARED_POST.USER_ID
WHERE 
ME_POST.REPOST_ID IS NOT NULL
AND FOL.IS_DELETED != 1


////////////////////User_post_views//////





SELECT 
ME_POST.ID POST_ID 
,0 as IS_DELETED_SHARED
,ME.ID USER_ID
,ME.USERNAME
,ME.FULL_NAME
,ME.IMAGE USER_IMAGE
,ME_POST.IMAGE
, ME_POST.CONTENT
, ME.ID GROUP_ID
, 'REGULAR_POST' POST_TYPE
, NULL ORGINAL_USERNAME
, NULL ORG_NAME
, NULL ORG_USER_IMAGE
, NULL ORG_MODIFIED
, NULL ORG_USER_ID
, ME_POST.IS_DELETED
,ME_POST.MODIFIED 
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN ME.ID = (SELECT b.user_id FROM likes as b where user_id =  ME.ID and post_id = ME_POST.ID and is_deleted = 0 ) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM users ME
LEFT JOIN posts ME_POST ON ME_POST.USER_ID= ME.ID
WHERE 
ME_POST.repost_id IS NULL
AND ME_POST.is_deleted != 1

union all

 
SELECT 
ME_POST.ID
, ME_POST.IS_DELETED as IS_DELETED_SHARED
,ME.ID USER_ID
,ME.USERNAME
,ME.FULL_NAME
,ME.IMAGE USER_IMAGE
, SHARED_POST.IMAGE
, SHARED_POST.CONTENT
, ME.ID GROUP_ID
, 'SHARED_POST' post_type
, ORG_USER.USERNAME ORG_USERNAME
, ORG_USER.FULL_NAME ORG_NAME
, ORG_USER.IMAGE ORG_USER_IMAGE
, SHARED_POST.modified ORG_MODIFIED
, ORG_USER.ID ORG_USER_ID
, SHARED_POST.IS_DELETED
, ME_POST.modified
,(select count(*) from likes where POST_ID = ME_POST.ID and is_deleted = 0) as LIKES_COUNT
,(select count(*) from comments where POST_ID = ME_POST.ID and is_deleted = 0) as COMMENTS_COUNT
,((CASE WHEN ME.ID = (SELECT b.user_id FROM likes as b where user_id = ME.ID and post_id = ME_POST.ID and is_deleted = 0) THEN 1 ELSE 0 END)) AS IS_LIKED
FROM users ME
LEFT JOIN posts ME_POST ON ME_POST.USER_ID= ME.ID
INNER JOIN posts SHARED_POST ON ME_POST.REPOST_ID = SHARED_POST.ID
LEFT JOIN users ORG_USER ON ORG_USER.ID = SHARED_POST.USER_ID








?>


<?php echo $this->Paginator->counter(array('format'=>__('Page {;page} of {:paps}, showing {:current} records out of {:count} total, starting on record {:start}, ending on {:end}'))); ?>

<div class="paging">
<?php

echo $this->Paginator->first("First");
echo $this->Paginator->prev(' prev', array(), null, array('class' => 'prev disabled')
);
echo $this->Paginator->numbers(array('separator' => ''));
echo $this->Paginator->next(' next', array(), null, array('class' => 'next disabled'));
echo $this->Paginator->last("Last");

?>
</div>

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `post_views`  AS 
SELECT `me_post`.`id` AS `POST_ID`, `me`.`id` AS `USER_ID`, `me`.`username` AS `USERNAME`, `me`.`full_name` AS `FULL_NAME`, `me`.`image` AS `USER_IMAGE`, `me_post`.`image` AS `IMAGE`, `me_post`.`content` AS `CONTENT`, `me`.`id` AS `GROUP_ID`, 'REGULAR_POST' AS `POST_TYPE`, NULL AS `ORGINAL_USERNAME`, NULL AS `ORG_NAME`, NULL AS `ORG_USER_IMAGE`, NULL AS `ORG_MODIFIED`, NULL AS `ORG_USER_ID`, `me_post`.`is_deleted` AS `IS_DELETED`, `me_post`.`modified` AS `MODIFIED`, (select count(0) from `likes` where `likes`.`post_id` = `me_post`.`id` and `likes`.`is_deleted` = 0) AS `LIKES_COUNT`, (select count(0) from `comments` where `comments`.`post_id` = `me_post`.`id` and `comments`.`is_deleted` = 0) AS `COMMENTS_COUNT`, CASE WHEN `me`.`id` = (select `b`.`user_id` from `likes` `b` where `b`.`user_id` = `me`.`id` AND `b`.`post_id` = `me_post`.`id` AND `b`.`is_deleted` = 0) THEN 1 ELSE 0 END AS `IS_LIKED` FROM (`users` `me` left join `posts` `me_post` on(`me_post`.`user_id` = `me`.`id`)) WHERE `me_post`.`repost_id` is null AND `me_post`.`is_deleted` <> 1 ;


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_post_views`  AS 
SELECT `me_post`.`id` AS `POST_ID`, `me`.`id` AS `USER_ID`, `me`.`username` AS `USERNAME`, `me`.`full_name` AS `FULL_NAME`, `me`.`image` AS `USER_IMAGE`, `me_post`.`image` AS `IMAGE`, `me_post`.`content` AS `CONTENT`, `me`.`id` AS `GROUP_ID`, 'REGULAR_POST' AS `POST_TYPE`, NULL AS `ORGINAL_USERNAME`, NULL AS `ORG_NAME`, NULL AS `ORG_USER_IMAGE`, NULL AS `ORG_MODIFIED`, NULL AS `ORG_USER_ID`, `me_post`.`is_deleted` AS `IS_DELETED`, `me_post`.`modified` AS `MODIFIED`, (select count(0) from `likes` where `likes`.`post_id` = `me_post`.`id` and `likes`.`is_deleted` = 0) AS `LIKES_COUNT`, (select count(0) from `comments` where `comments`.`post_id` = `me_post`.`id` and `comments`.`is_deleted` = 0) AS `COMMENTS_COUNT`, CASE WHEN `me`.`id` = (select `b`.`user_id` from `likes` `b` where `b`.`user_id` = `me`.`id` AND `b`.`post_id` = `me_post`.`id` AND `b`.`is_deleted` = 0) THEN 1 ELSE 0 END AS `IS_LIKED` FROM (`users` `me` left join `posts` `me_post` on(`me_post`.`user_id` = `me`.`id`)) WHERE `me_post`.`repost_id` is null AND `me_post`.`is_deleted` <> 1 ;






id] => 44 [full_name] => Larry Page [email] => larrypage@gmail.com [birthdate] => 1990-01-01 [username] => larrypage [password] => $2a$10$LFLbCt/0infk4WAl/BWATOLvc3znJJ8JoG/1U9o8r6U0lFH8GUOra [image] => default-profile.jpg [is_deleted] => [code_of_activation] => - [email_activated] => 2021-02-23 23:26:23 [created] => 2021-02-23 23:23:56 [modified] => 2021-02-23 23:23:56 [deleted] => ) )