<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 7;
?>
<body>

    <div class="wrapper">
    <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-common.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">

                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- <div class="card"> -->

                            <div>
                                <header>
                                    <h1 class="text-center" id="gametitle">Game Name</h1>
                                </header>
                                <div class="scorecontainer">
                                    <div class="btncontainer">
                                        <h2 class="teamtitle" id="teamtitle1">Home</h2>
                                        <div class="btn" id="team1">0</div>
                                        <!-- <button class="scorebtn" id="homeplus">+</button>
                                    <button class="scorebtn" id="homeminus">-</button> -->
                                    </div>
                                    <div id="roundcounter"> 
                                        <!-- <button id="roundplus">+</button> -->
                                        <div id="rounddisplay">
                                            <p>Time</p>
                                            <strong><p id="roundnum">00:00<p></strong>
                                        </div>
                                        <!-- <button id="roundminus">-</button> -->
                                    </div>
                                    <div class="btncontainer">
                                        <h2 class="teamtitle" id="teamtitle2">Away</h2>
                                        <div class="btn" id="team2">0</div>
                                        <!-- <button class="scorebtn" id="awayplus">+</button>
                                        <button class="scorebtn" id="awayminus">-</button> -->
                                    </div>
                                </div>
                            </div>

                            <!-- </div> -->
                        </div>
                    </div>

                </div>
            </div>

        </div>


    </div>

    

    

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/common.js"></script>


</body>