<div id="wrapper" class="sidebar toggled" data-background-color="white" data-active-color="danger">
    <div class="sidebar-wrapper" id="sidebar-wrapper">
        <div class="logo" style="text-align: center">
            <a href="/Scoreboard/index.php" class="simple-text logo-normal">
                All-in-One Scoreboard
            </a>
        </div>

        <ul class="nav">
            <li>
                <a href="index.php">
                    <i class="ti-panel"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li>
                <a href="basketball.php">
                    <i class="ti-basketball"></i>
                    <p>Basketball</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="ti-basketball"></i>
                    <p>Volleyball</p>
                </a>
            </li>
            <li>
                <a href="badminton.php">
                    <i class="ti-panel"></i>
                    <p>Badminton</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="ti-panel"></i>
                    <p>Sipak Takraw</p>
                </a>
            </li>
            <li>
                <a href="common.php">
                    <i class="ti-panel"></i>
                    <p>Common</p>
                </a>
            </li>
            <li class="active">
                <a href="logs.php">
                    <i class="ti-view-list-alt"></i>
                    <p>Logs</p>
                </a>
            </li>
        </ul>
    </div>
</div>