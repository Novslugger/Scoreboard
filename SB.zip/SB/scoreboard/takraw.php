<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 6;
?>
<body>

    <div class="wrapper">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-takraw.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">

                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- <div class="card"> -->

                            <div>
                                <header>
                                    <h1 class="text-center">Game Name</h1>
                                </header>
                                <div class="scorecontainer">
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Home</h2>
                                        <div class="btn" id="team1">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Sets Won</p>
                                            <strong><p style="color: red; font-size: 30px">0<p></strong>
                                        </span>
                                    </div>
                                    <div id="roundcounter"> 
                                        <!-- <button id="roundplus">+</button> -->
                                        <div id="rounddisplay">
                                            <p>Set</p>
                                            <strong><p id="roundnum">1<p></strong>
                                        </div>
                                        <!-- <button id="roundminus">-</button> -->
                                    </div>
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Away</h2>
                                        <div class="btn" id="team2">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Sets Won</p>
                                            <strong><p style="color: red; font-size: 30px">0<p></strong>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <!-- </div> -->
                        </div>
                    </div>

                </div>
            </div>

        </div>


    </div>

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/home.js"></script>


</body>