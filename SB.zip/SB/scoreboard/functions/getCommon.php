<?php  

    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/database/connection.php';


    $stmt = $mysqli->query("SELECT * FROM common_scores ORDER BY ID DESC LIMIT 1");
    while($row = $stmt->fetch_assoc()){

        echo $row['home_team_score'] . "|" . $row['away_team_score'] . "|" . $row['home_team'] . "|" . $row['away_team'] . "|" . $row['game_name'];

    }
?>