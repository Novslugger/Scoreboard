<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 3;
?>
<body>

    <div class="wrapper">
    <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-basketball.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">

                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- <div class="card"> -->

                            <div>
                                <header>
                                    <h1 class="text-center">Game Name</h1>
                                </header>
                                <div class="scorecontainer">
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Home</h2>
                                        <div class="btn" id="team1">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Fouls</p>
                                            <strong><p style="color: red; font-size: 30px">00<p></strong>
                                        </span>
                                        <!-- <button class="scorebtn" id="homeminus">-</button> -->
                                    </div>
                                    <div id="roundcounter"> 
                                        <!-- <button id="roundplus">+</button> -->
                                        <br/>
                                        <br/>
                                        <div id="rounddisplay">
                                            <p style="font-size: 30px">Time</p>
                                            <strong><p id="roundnum" style="font-size: 24px">00:00<p></strong>
                                        </div>
                                        <br/>
                                        <div id="rounddisplay">
                                            <p style="font-size: 30px">Period</p>
                                            <strong><p id="roundnum" style="font-size: 24px">0<p></strong>
                                        </div>
                                        <br/>
                                        <div id="rounddisplay">
                                            <p style="font-size: 15px">Shot Clock</p>
                                            <strong><p id="roundnum" style="font-size: 24px">00:00<p></strong>
                                        </div>
                                        <!-- <button id="roundminus">-</button> -->
                                    </div>
                                    <div class="btncontainer">
                                        <h2 class="t    eamtitle">Away</h2>
                                        <div class="btn" id="team2">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Fouls</p>
                                            <strong><p style="color: red; font-size: 30px">00<p></strong>
                                        </span>
                                        <!-- <button class="scorebtn" id="awayplus">+</button>
                                        <button class="scorebtn" id="awayminus">-</button> -->
                                    </div>
                                </div>
                            </div>

                            <!-- </div> -->
                        </div>
                    </div>

                </div>
            </div>

        </div>


    </div>

    

    

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/home.js"></script>


</body>