
    <script src="assets/js/jquery-1.12.4.min.js"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>
	<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
	<script src="assets/js/chartist.min.js"></script>
    <script src="assets/js/bootstrap-notify.js"></script>
	<script src="assets/js/paper-dashboard-old.js"></script>
	<!-- <script src="assets/js/chart.js"></script> -->
	<script src="assets/js/chartjs.min.js"></script>
	<script src="scripts/master.js"></script>