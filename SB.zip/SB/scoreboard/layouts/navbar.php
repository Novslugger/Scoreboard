<nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
    <div class="container-fluid">
        
        <div class="navbar-header">
            <a class="navbar-brand" href="#">  
                <?php            
                    if ($pageindicator == 1)
                    {
                        echo "Dashboard";
                    }
                    elseif ($pageindicator == 2)
                    {
                        echo "Logs";
                    }         
                    elseif ($pageindicator == 3)
                    {
                        echo "Basketball";
                    }           
                    elseif ($pageindicator == 4)
                    {
                        echo "Volleyball";
                    }            
                    elseif ($pageindicator == 5)
                    {
                        echo "Badminton";
                    }            
                    elseif ($pageindicator == 6)
                    {
                        echo "Sipak Takraw";
                    }            
                    elseif ($pageindicator == 7)
                    {
                        echo "Common Scoreboard";
                    }            
                ?>            
            </a> 
            
        </div>     
        
        <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="#menu-toggle" id="menu-toggle" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="ti-menu"></i>
                </a>
            </li>
        </ul>
    </div>
</nav>