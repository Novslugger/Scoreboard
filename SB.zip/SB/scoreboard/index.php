<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 1;
?>
<body>

    <div class="wrapper">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-home.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">          

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> Controller</h4>
                            </div>
                            <hr/>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th> Name </th>
                                            <th> Username </th>
                                            <th> User Type </th>
                                            <th> Date Created </th>
                                            <th> Status </th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td> test </td>
                                                <td> test </td>
                                                <td> test </td>
                                                <td> test </td>
                                                <td> test </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>


    </div>

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/home.js"></script>


</body>