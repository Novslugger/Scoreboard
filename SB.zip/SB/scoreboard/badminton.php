<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 5;
?>
<body>

    <div class="wrapper">
    <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-badminton.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">

                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- <div class="card"> -->

                            <div>
                                <header>
                                    <h1 class="text-center">Game Name</h1>
                                </header>
                                <div class="scorecontainer">
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Home</h2>
                                        <div class="btn" id="team1">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Set</p>
                                            <strong><p style="color: red; font-size: 30px">00<p></strong>
                                        </span>
                                        <!-- <button class="scorebtn" id="homeplus">+</button>
                                    <button class="scorebtn" id="homeminus">-</button> -->
                                    </div>
                                    <div id="roundcounter"> 
                                        <!-- <button id="roundplus">+</button> -->
                                        <div id="rounddisplay">
                                            <p style="font-size: 30px">Time</p>
                                            <strong><p id="roundnum" style="font-size: 24px">00:00<p></strong>
                                        </div>
                                        <br/><br/>
                                        <div id="rounddisplay">
                                            <p style="font-size: 25px">Serving</p>
                                            <!-- <strong><p id="roundnum" style="font-size: 24px">00:00<p></strong> -->
                                            <center>
                                                <p class="triangle-left"></p>
                                            </center>
                                            <!-- <div class="triangle-right"></div> -->
                                        </div>
                                        <!-- <button id="roundminus">-</button> -->
                                    </div>
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Away</h2>
                                        <div class="btn" id="team2">0</div>
                                        <br/><br/>
                                        <span class="scorebtn" id="homeplus">
                                            <p>Set</p>
                                            <strong><p style="color: red; font-size: 30px">00<p></strong>
                                        </span>
                                        <!-- <button class="scorebtn" id="awayplus">+</button>
                                        <button class="scorebtn" id="awayminus">-</button> -->
                                    </div>
                                </div>
                            </div>

                            <!-- </div> -->
                        </div>
                    </div>

                </div>
            </div>

        </div>


    </div>

    

    

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/home.js"></script>


</body>