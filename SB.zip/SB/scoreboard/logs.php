<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 2;
?>
<body>

    <div class="wrapper">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-logs.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">
                
                    <div class="row">                        
                        <div class="col-md-12">
                            <div class="card">

                                

                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>
    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/logs.js"></script>


</body>