<?php
    // Header
    include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/header.php';

    $pageindicator = 4;
?>
<body>

    <div class="wrapper">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/side-menu/sm-volleyball.php'; ?>
    
        <div class="main-panel" id="page-content-wrapper">    

        <?php include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">

                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- <div class="card"> -->

                            <div>
                                <header>
                                    <h1 class="text-center">Game Name</h1>
                                </header>
                                <div class="scorecontainer" style="height: 700px !important">
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Home</h2>
                                        <div class="btn" id="team1">0</div>

                                        <br/>
                                        <br/>
                                        Set 1
                                        <br/>
                                        <p class="scorebtn" id="homeplus">00</p>
                                        <p class="scorebtn" id="homeminus">00</p>

                                        <br/>
                                        <br/>
                                        Set 2
                                        <br/>
                                        <p class="scorebtn" id="homeplus">00</p>
                                        <p class="scorebtn" id="homeminus">00</p>
                                    </div>
                                    <div id="roundcounter"> 
                                        <!-- <button id="roundplus">+</button> -->
                                        <div id="rounddisplay" style="width: 150px !important">
                                            <strong>
                                                <p id="roundnum" style="font-size: 20px">
                                                    <span style="color: red;">00</span> 
                                                    <span>:</span> 
                                                    <span style="color: red;">60</span>
                                                <p>
                                            </strong>
                                        </div>
                                        <br/>
                                        <div id="rounddisplay" style="width: 150px !important">
                                            <p>Set</p>
                                            <strong><p id="roundnum" style="font-size: 20px">0</strong>
                                        </div>
                                        <br/>
                                        <div id="rounddisplay" style="width: 150px !important">
                                            <strong>
                                                <p id="roundnum" style="font-size: 20px">
                                                    <span style="color: red;">0</span> 
                                                    <span>:Timeout:</span> 
                                                    <span style="color: red;">0</span>
                                                <p>
                                            </strong>
                                        </div>
                                        <br/>
                                        <div id="rounddisplay" style="width: 150px !important">
                                            <strong>
                                                <p id="roundnum" style="font-size: 20px">
                                                    <span style="color: red;">0</span> 
                                                    <span>:Set Won:</span> 
                                                    <span style="color: red;">0</span>
                                                <p>
                                            </strong>
                                        </div>
                                        <!-- <button id="roundminus">-</button> -->
                                    </div>
                                    <div class="btncontainer">
                                        <h2 class="teamtitle">Away</h2>
                                        <div class="btn" id="team2">0</div>

                                        <br/>
                                        <br/>
                                        Set 3
                                        <br/>
                                        <p class="scorebtn" id="homeplus">00</p>
                                        <p class="scorebtn" id="homeminus">00</p>

                                        <br/>
                                        <br/>
                                        Set 4
                                        <br/>
                                        <p class="scorebtn" id="homeplus">00</p>
                                        <p class="scorebtn" id="homeminus">00</p>
                                    </div>
                                </div>
                            </div>

                            <!-- </div> -->
                        </div>
                    </div>

                </div>
            </div>

        </div>


    </div>

    <?php
        // Footer
        include $_SERVER['DOCUMENT_ROOT'].'/scoreboard/layouts/footer.php';
    ?>
    <script src="scripts/home.js"></script>


</body>