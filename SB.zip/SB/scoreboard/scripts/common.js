$('document').ready(function(){

    var counter = 0;
    setInterval( function() {

        // $("#team1").text(counter);
        // $("#team2").text(counter);
        // counter = counter + 1;

        $.ajax({
            type: 'POST',
            url: 'functions/getCommon.php',
            success: function (data) {
                    // alert(data);
                    var x = data.split("|");

                    $("#team1").text(x[0]);
                    $("#team2").text(x[1]);

                    $("#teamtitle1").text(x[2]);
                    $("#teamtitle2").text(x[3]);

                    $("#gametitle").text(x[4]);

                }
            });


        
    }, 1000);


});

