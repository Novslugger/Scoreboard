$('document').ready(function(){

    

	
});

var ctx = document.getElementById("logsChart");
var logsChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
            label: 'Air Quality',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(151,187,205,0.5)'
            ],
            borderColor: [
                'rgba(151,187,205,1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});