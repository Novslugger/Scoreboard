<?php

    include $_SERVER['DOCUMENT_ROOT'].'/Water Quality (Senior High 2020)/database/connection.php';

    // Prepare the SQL statement

    $mysqli->query("INSERT INTO sensor_data (Turbidity_Data, TDS_Data, PH_Data) VALUES ('".$_GET["Turbidity_Data"]."','".$_GET["TDS_Data"]."','".$_GET["PH_Data"]."')");
    
?>