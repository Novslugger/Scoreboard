-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2021 at 03:30 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scoreboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `badminton_scores`
--

CREATE TABLE `badminton_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `badminton_scores`
--

INSERT INTO `badminton_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`) VALUES
(4, 'nhs vs chsi', 'asd', 'fgh', 1, 2, 1, '2021-02-22 23:56:15', NULL),
(5, 'nhs vs chsi', 'asd', 'fgh', 7, 7, 2, '2021-02-22 23:56:24', NULL),
(7, 'nhs vs chsi', 'asd', 'fgh', 8, 8, 3, '2021-02-23 00:04:05', NULL),
(8, 'test103', 'a', 'b', 5, 3, 1, '2021-02-25 15:27:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `basketball_scores`
--

CREATE TABLE `basketball_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `home_team_foul` int(11) DEFAULT NULL,
  `away_team_foul` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `basketball_scores`
--

INSERT INTO `basketball_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `home_team_foul`, `away_team_foul`, `created`) VALUES
(1, 'g', 'Brgy. Ormoc', 'Brgy. Isabel', 1, 2, 1, 0, 0, '2021-02-20 22:58:54'),
(2, 'g', 'Brgy. Ormoc', 'Brgy. Isabel', 3, 8, 2, 0, 1, '2021-02-20 23:05:01'),
(3, 'b', 'aa', 'cc', 4, 3, 1, 1, 1, '2021-02-22 23:50:38');

-- --------------------------------------------------------

--
-- Table structure for table `common_scores`
--

CREATE TABLE `common_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `common_scores`
--

INSERT INTO `common_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`) VALUES
(1, 'b1vsb2', 'B1', 'B2', 5, 5, 1, '2021-02-22 23:57:36'),
(4, 'b1vsb2', 'B1', 'B2', 6, 6, 2, '2021-02-23 00:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `takraw_scores`
--

CREATE TABLE `takraw_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `takraw_scores`
--

INSERT INTO `takraw_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`) VALUES
(1, 'st', 'st1', 'st2', 2, 1, 1, '2021-02-22 23:51:44', NULL),
(2, 'st', 'st1', 'st2', 5, 5, 2, '2021-02-22 23:51:54', NULL),
(3, 'test102', 'a', 'b', 3, 4, 1, '2021-02-25 15:25:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `volleyball_scores`
--

CREATE TABLE `volleyball_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `volleyball_scores`
--

INSERT INTO `volleyball_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`) VALUES
(1, 'abcd', 'north', 'south', 10, 10, 1, '2021-02-22 23:51:14', NULL),
(2, 'abcd', 'north', 'south', 12, 12, 2, '2021-02-22 23:51:31', NULL),
(3, 'test101', 'aa', 'bb', 5, 4, 1, '2021-02-25 15:22:29', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `badminton_scores`
--
ALTER TABLE `badminton_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basketball_scores`
--
ALTER TABLE `basketball_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `common_scores`
--
ALTER TABLE `common_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `takraw_scores`
--
ALTER TABLE `takraw_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volleyball_scores`
--
ALTER TABLE `volleyball_scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `badminton_scores`
--
ALTER TABLE `badminton_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `basketball_scores`
--
ALTER TABLE `basketball_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `common_scores`
--
ALTER TABLE `common_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `takraw_scores`
--
ALTER TABLE `takraw_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `volleyball_scores`
--
ALTER TABLE `volleyball_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
