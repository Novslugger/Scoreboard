-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2021 at 10:12 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scoreboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `badminton_scores`
--

CREATE TABLE `badminton_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL,
  `time_in_minute` varchar(250) DEFAULT NULL,
  `is_time_started` int(11) DEFAULT NULL,
  `reset_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `badminton_scores`
--

INSERT INTO `badminton_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`, `time_in_minute`, `is_time_started`, `reset_time`) VALUES
(4, 'nhs vs chsi', 'asd', 'fgh', 1, 2, 1, '2021-02-22 23:56:15', NULL, '', 0, 0),
(5, 'nhs vs chsi', 'asd', 'fgh', 7, 7, 2, '2021-02-22 23:56:24', NULL, '', 0, 0),
(7, 'nhs vs chsi', 'asd', 'fgh', 8, 8, 3, '2021-02-23 00:04:05', NULL, '', 0, 0),
(8, 'test103', 'Team A', 'Team B', 9, 11, 1, '2021-02-25 15:27:29', 2, '40', 0, 1),
(9, 'new game', '', NULL, NULL, NULL, 1, '2021-03-24 21:37:47', NULL, NULL, NULL, NULL),
(10, 'gg1', '', NULL, NULL, NULL, 1, '2021-03-24 21:49:01', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `basketball_scores`
--

CREATE TABLE `basketball_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) DEFAULT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `home_team_foul` int(11) DEFAULT NULL,
  `away_team_foul` int(11) DEFAULT NULL,
  `time_in_minute` varchar(250) DEFAULT NULL,
  `is_time_started` int(11) DEFAULT NULL,
  `reset_time` int(11) DEFAULT NULL,
  `shot_clock` varchar(250) DEFAULT NULL,
  `shot_clock_started` int(11) DEFAULT NULL,
  `reset_shotclock` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `basketball_scores`
--

INSERT INTO `basketball_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `home_team_foul`, `away_team_foul`, `time_in_minute`, `is_time_started`, `reset_time`, `shot_clock`, `shot_clock_started`, `reset_shotclock`, `created`) VALUES
(1, 'g', 'Brgy. Ormoc', 'Brgy. Isabel', 1, 2, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-20 22:58:54'),
(2, 'g', 'Brgy. Ormoc', 'Brgy. Isabel', 3, 8, 2, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-20 23:05:01'),
(3, 'b', 'aa', 'cc', 4, 3, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-22 23:50:38'),
(4, 'basket1', 'a', 'b', 1, 2, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-16 22:15:43'),
(5, 'g', 'Team A', 'Team B', 8, 11, 3, 2, 2, '8:30', 1, 1, '24', 0, 0, '2021-03-18 00:49:54'),
(6, 'g', 'Team A', 'Team B', 6, 3, 4, 0, 0, '8:30', 1, 1, '14', 1, 0, '2021-03-18 23:58:45'),
(10, 'testgame', NULL, NULL, NULL, NULL, 1, NULL, NULL, '10', 1, 0, NULL, NULL, NULL, '2021-03-19 01:42:29'),
(11, 'new game', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-24 21:27:17'),
(12, 'gg1234', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-24 21:49:32');

-- --------------------------------------------------------

--
-- Table structure for table `common_scores`
--

CREATE TABLE `common_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `time_in_minute` varchar(250) DEFAULT NULL,
  `is_time_started` int(11) DEFAULT NULL,
  `reset_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `common_scores`
--

INSERT INTO `common_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `time_in_minute`, `is_time_started`, `reset_time`) VALUES
(1, 'b1vsb2', 'B1', 'B2', 5, 5, 1, '2021-02-22 23:57:36', NULL, NULL, NULL),
(4, 'b1vsb2', 'B1', 'B2', 6, 6, 2, '2021-02-23 00:03:11', NULL, NULL, NULL),
(5, 'common game', 'Team 1', 'Team 2', 4, 10, 1, '2021-03-16 23:05:17', '15', 0, 1),
(6, 'common game', '', NULL, NULL, NULL, 2, '2021-03-20 01:27:35', '15', 0, 1),
(7, 'new game', '', NULL, NULL, NULL, 1, '2021-03-24 21:37:33', NULL, NULL, NULL),
(8, 'game1', '', NULL, NULL, NULL, 1, '2021-03-24 21:42:35', NULL, NULL, NULL),
(9, 'new', '', NULL, NULL, NULL, 1, '2021-03-24 21:44:56', NULL, NULL, NULL),
(10, 'gg1', '', NULL, NULL, NULL, 1, '2021-03-24 21:46:16', NULL, NULL, NULL),
(11, 'gg2', '', NULL, NULL, NULL, 1, '2021-03-24 21:48:41', '120', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `takraw_scores`
--

CREATE TABLE `takraw_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `takraw_scores`
--

INSERT INTO `takraw_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`) VALUES
(1, 'st', 'st1', 'st2', 2, 1, 1, '2021-02-22 23:51:44', NULL),
(2, 'st', 'st1', 'st2', 6, 5, 2, '2021-02-22 23:51:54', NULL),
(3, 'test102', 'Team A', 'Team B', 3, 5, 1, '2021-02-25 15:25:42', 2),
(4, 'gg2', '', NULL, NULL, NULL, 1, '2021-03-24 21:49:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `usertypeid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `usertypeid`, `status`, `createdDate`) VALUES
(1, 'score', 'score', '1234', 1, 1, '2021-03-10 20:30:42'),
(2, 'timer', 'timer', '1234', 2, 1, '2021-03-18 20:30:42'),
(3, 'shotclock', 'shotclock', '1234', 3, 1, '2021-03-18 20:30:42');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `id` int(20) NOT NULL,
  `type` varchar(225) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`id`, `type`, `status`, `created`) VALUES
(1, 'scorer/foul/serve', 1, '2021-03-05 16:37:14'),
(2, 'timer/quater/period/timeout/set', 1, '2021-03-05 16:37:14'),
(3, 'shot clock', 1, '2021-03-05 16:37:14');

-- --------------------------------------------------------

--
-- Table structure for table `volleyball_scores`
--

CREATE TABLE `volleyball_scores` (
  `id` int(11) NOT NULL,
  `game_name` varchar(250) DEFAULT NULL,
  `home_team` varchar(250) NOT NULL,
  `away_team` varchar(250) DEFAULT NULL,
  `home_team_score` int(20) DEFAULT NULL,
  `away_team_score` int(20) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `serve` int(255) DEFAULT NULL,
  `time_in_minute` varchar(250) DEFAULT NULL,
  `is_time_started` int(11) DEFAULT NULL,
  `reset_time` int(11) DEFAULT NULL,
  `home_timeout` int(11) DEFAULT NULL,
  `away_timeout` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `volleyball_scores`
--

INSERT INTO `volleyball_scores` (`id`, `game_name`, `home_team`, `away_team`, `home_team_score`, `away_team_score`, `period`, `created`, `serve`, `time_in_minute`, `is_time_started`, `reset_time`, `home_timeout`, `away_timeout`) VALUES
(1, 'abcd', 'north', 'south', 10, 10, 1, '2021-02-22 23:51:14', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'abcd', 'north', 'south', 12, 12, 2, '2021-02-22 23:51:31', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'test101', 'Team A', 'Team B', 8, 9, 1, '2021-02-25 15:22:29', 2, '12', 1, 1, NULL, NULL),
(4, 'gg1', '', NULL, NULL, NULL, 1, '2021-03-24 21:49:14', NULL, '1200', 1, 0, 2, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `badminton_scores`
--
ALTER TABLE `badminton_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basketball_scores`
--
ALTER TABLE `basketball_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `common_scores`
--
ALTER TABLE `common_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `takraw_scores`
--
ALTER TABLE `takraw_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volleyball_scores`
--
ALTER TABLE `volleyball_scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `badminton_scores`
--
ALTER TABLE `badminton_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `basketball_scores`
--
ALTER TABLE `basketball_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `common_scores`
--
ALTER TABLE `common_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `takraw_scores`
--
ALTER TABLE `takraw_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `volleyball_scores`
--
ALTER TABLE `volleyball_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
