<?php

/*
 * Database Constants
 */
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'scoreboard');

//Connecting to the database
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

//checking the successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//making an array to store the response
$response = array();

//if there is a post request move ahead
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //getting the data from request
   
	
	if(isset($_POST['game_name'])){
		$game_name = $_POST['game_name'];
	}
	
	if(isset($_POST['home_team'])){
    $home_team = $_POST['home_team'];
	}
	
	if(isset($_POST['away_team'])){
    $away_team = $_POST['away_team'];
	}
	
	if(isset($_POST['away_team_score'])){
    $away_team_score = $_POST['away_team_score'];
	}
	
	if(isset($_POST['home_team_score'])){
    $home_team_score = $_POST['home_team_score'];
	}
	
	if(isset($_POST['period'])){
    $period = $_POST['period'];
	}
	
	if(isset($_POST['home_team_foul'])){
    $home_team_foul = $_POST['home_team_foul'];
	}
	
	if(isset($_POST['away_team_foul'])){
    $away_team_foul = $_POST['away_team_foul'];
	}
	
	if(isset($_POST['game_type'])){
    $game_type = $_POST['game_type'];
	}
	
	if(isset($_POST['serve'])){
	$serve = $_POST['serve'];
	}
	
	if(isset($_POST['user_name'])){
	$username = $_POST['user_name'];
	}
	
	if(isset($_POST['pass_word'])){
	$password = $_POST['pass_word'];
	}
	
	if(isset($_POST['user_type'])){
	$user_type = $_POST['user_type'];
	}
	
	
	//time
	if(isset($_POST['time_in_minute'])){
	$time_in_minute = ($_POST['time_in_minute'] * 60);
	}
	if(isset($_POST['is_time_started'])){
	$is_time_started = $_POST['is_time_started'];
	}
	if(isset($_POST['reset_time'])){
	$reset_time = $_POST['reset_time'];
	}
	
	
	//shotclock
	if(isset($_POST['shot_clock'])){
	$shot_clock = $_POST['shot_clock'];
	}
	if(isset($_POST['shot_clock_started'])){
	$shot_clock_started = $_POST['shot_clock_started'];
	}
	if(isset($_POST['reset_shotclock'])){
	$reset_shotclock = $_POST['reset_shotclock'];
	}
	
	//volley time out
	if(isset($_POST['home_out_count'])){
	$home_out_count = $_POST['home_out_count'];
	}
	if(isset($_POST['away_out_count'])){
	$away_out_count = $_POST['away_out_count'];
	}
	
	
	if(isset($_POST['new_game'])){
	$new_game = $_POST['new_game'];
	$tbl_name = $_POST['tbl_name'];
	
	    $sql = "select * from ". $tbl_name ." where game_name = '" . $new_game . "' and period = 1";
        $query = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($query);

    
			if ($count > 0) {

				$response['message'] = $new_game." Already exists.";

			} else {

				mysqli_query($conn, "INSERT INTO ".$tbl_name." (game_name, period)
			VALUES ('" . $new_game . "',1)");

				$response['message'] =  $new_game." Data successfully saved.";
			}
	}
	
	
		if(isset($game_type)){
			if ($game_type == "basketball_scores") {

				$sql = "select * from basketball_scores where game_name = '" . $game_name . "' and period = '" . $period . "'";
				$query = mysqli_query($conn, $sql);
				$count = mysqli_num_rows($query);

				if($user_type == 1){
					if ($count > 0) {

						mysqli_query($conn, "update basketball_scores set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
							,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "'
							,period = '" . $period . "' ,home_team_foul = '" . $home_team_foul . "', away_team_foul = '" . $away_team_foul . "'
							where game_name = '" . $game_name . "' and period = '" . $period . "'"
						);
						$response['message'] = $game_type." Data successfully saved. with user type ".$user_type;

					} else {

						mysqli_query($conn, "INSERT INTO basketball_scores (game_name, home_team ,away_team, away_team_score, home_team_score, period, home_team_foul, away_team_foul)
					VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period, $home_team_foul, $away_team_foul)");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
				
				 if($user_type == 2){
					if ($count > 0) {

						mysqli_query($conn, "update basketball_scores set time_in_minute = '" . $time_in_minute . "', is_time_started = '" . $is_time_started . "', reset_time = '" . $reset_time . "' where game_name = '" . $game_name . "' and period = '" . $period . "'");
						$response['message'] = $game_type." Data successfully saved. with user type ".$user_type;

					} else {

						mysqli_query($conn, "INSERT INTO basketball_scores (game_name, period, time_in_minute, is_time_started, reset_time)
					VALUES ('" . $game_name . "','" . $period . "','" . $time_in_minute . "','" . $is_time_started . "','" . $reset_time . "')");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
				
				 if($user_type == 3){
					if ($count > 0) {

						mysqli_query($conn, "update basketball_scores set shot_clock = '" . $shot_clock . "', shot_clock_started = '" . $shot_clock_started . "', reset_shotclock = '" . $reset_shotclock . "' where game_name = '" . $game_name . "' and period = '" . $period . "'");
						
						$response['message'] = $game_type." Data successfully saved. with user type ".$user_type;

					} else {

						mysqli_query($conn, "INSERT INTO basketball_scores (game_name, period, shot_clock, shot_clock_started, reset_shotclock)
					VALUES ('" . $game_name . "', $period, '" . $shot_clock . "', $shot_clock_started, $reset_shotclock)");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
				
				
				
			} else if ($game_type == "common_scores") {

				$sql = "select * from " . $game_type . " where game_name = '" . $game_name . "' and period = '" . $period . "'";
				$query = mysqli_query($conn, $sql);
				$count = mysqli_num_rows($query);
	          
			    if($user_type == 1){
					if ($count > 0) {

						mysqli_query($conn, "update " . $game_type . " set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
							,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "'
							,period = '" . $period . "' where game_name = '" . $game_name . "' and period = '" . $period . "'"
						);
						$response['message'] =  $game_type." Data successfully saved.";

					} else {

						mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, home_team ,away_team, away_team_score, home_team_score, period)
					VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period)");
					
						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
				
				if($user_type == 2){
					if ($count > 0) {

						mysqli_query($conn, "update " . $game_type . " set time_in_minute = '" . $time_in_minute . "', is_time_started = '" . $is_time_started . "', reset_time = '" . $reset_time . "' where game_name = '" . $game_name . "' and period = '" . $period . "'");
						$response['message'] = $game_type." Data successfully saved. with user type ".$user_type;

					} else {

						mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, period, time_in_minute, is_time_started, reset_time)
					VALUES ('" . $game_name . "','" . $period . "','" . $time_in_minute . "','" . $is_time_started . "','" . $reset_time . "')");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
				
				

			 } else if ($game_type == "login") {

				
					$sql = "select * from users where username = '".$username."' and password = '".$password."' and status != 0";
					$query = mysqli_query($conn, $sql);
					$count = mysqli_num_rows($query);

						if($count > 0){
							$row = mysqli_fetch_array($query);
							   $response['message'] = "success";
							   $response['type'] = $row['usertypeid'];
						}else{
							$response['message'] = "failed";
						}
				

			} else if ($game_type == "takraw_scores") {
				
				$sql = "select * from " . $game_type . " where game_name = '" . $game_name . "' and period = '" . $period . "'";
				$query = mysqli_query($conn, $sql);
				$count = mysqli_num_rows($query);

               
				if ($count > 0) {

					mysqli_query($conn, "update " . $game_type . " set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
						,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "' ,serve = '" . $serve . "',period = '" . $period . "' where game_name = '" . $game_name . "' and period = '" . $period . "'"
					);
					$response['message'] =  $game_type." Data successfully saved.";

				} else {

					mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, home_team ,away_team, away_team_score, home_team_score, period,serve)
				VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period, $serve)");

					$response['message'] = "Data successfully saved.";
				}
			
		    } else {
				
				$sql = "select * from " . $game_type . " where game_name = '" . $game_name . "' and period = '" . $period . "'";
				$query = mysqli_query($conn, $sql);
				$count = mysqli_num_rows($query);

               	if($user_type == 1){
					if ($count > 0) {

						mysqli_query($conn, "update " . $game_type . " set game_name = '" . $game_name . "', home_team = '" . $home_team . "'
							,away_team = '" . $away_team . "' ,away_team_score = '" . $away_team_score . "' ,home_team_score = '" . $home_team_score . "' ,serve = '" . $serve . "',period = '" . $period . "' where game_name = '" . $game_name . "' and period = '" . $period . "'"
						);
						$response['message'] =  $game_type." Data successfully saved.";

					} else {

						mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, home_team ,away_team, away_team_score, home_team_score, period,serve)
					VALUES ('" . $game_name . "','" . $home_team . "', '" . $away_team . "', $away_team_score, $home_team_score, $period, $serve)");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
			    }
				
				if($user_type == 2){
					if ($count > 0) {

						mysqli_query($conn, "update " . $game_type . " set time_in_minute = '" . $time_in_minute . "', is_time_started = '" . $is_time_started . "', reset_time = '" . $reset_time . "', home_timeout = '" . $home_out_count . "', away_timeout = '" . $away_out_count . "' where game_name = '" . $game_name . "' and period = '" . $period . "'");
						$response['message'] = $game_type." Data successfully updated. with user type ".$user_type." ".  $home_out_count;

					} else {

						mysqli_query($conn, "INSERT INTO " . $game_type . " (game_name, period, time_in_minute, is_time_started, reset_time, home_timeout, away_timeout)
					VALUES ('" . $game_name . "','" . $period . "','" . $time_in_minute . "','" . $is_time_started . "','" . $reset_time . "', '" . $home_out_count . "', '" . $away_out_count . "')");

						$response['message'] =  $game_type." Data successfully saved. with user type ".$user_type;
					}
				}
		    }
		}

} else {
    $response['error'] = true;
    $response['message'] = "Invalid request";
	 $response['type'] = $_SERVER['REQUEST_METHOD'];
}

//displaying the data in json format
echo json_encode($response);